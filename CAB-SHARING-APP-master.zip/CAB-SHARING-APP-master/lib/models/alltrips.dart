import './requestdetails.dart';

final List<RequestDetails> allTrips = [];
